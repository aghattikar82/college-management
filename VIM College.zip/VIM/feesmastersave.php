<?php  
try

{
	
	$subject=$_POST["subject"];
	$matter=$_POST["matter"];
	$leavedate=$_POST["leavedate"];
	$noofleavedays=$_POST["noofleavedays"];

$con=mysqli_connect("localhost","root","admin","vim");
$stmt=$con->prepare("insert into tblstaffleave values(null,?,?,?,?,'0','0','0','0')");
 $stmt->bind_param("ssss",$subject,$matter,$leavedate,$noofleavedays);
	
	$i=$stmt->execute();
	$con->close();



	if(intval($i)==1)
	{
		header("Location:staffleaveregister.php?msg=Fees Paid Successfully");

	}
	else
	{
		//header("Location:staffleaveregister.php?msg=Registration Failed");

	}
	
	}

	catch(exception $exc)
	{
                       print("Exception".$exc);
	}
?>

