<?php 
if(isset($_COOKIE["username"])) 
{  
				?>
				<script language="javascript" type="text/javascript">
					location.href="adminmain.php";
				</script>
				<?php
} 
else if(isset($_COOKIE["advocateid"])) 
{  
				?>
				<script language="javascript" type="text/javascript">
					location.href="advocatehome.php";
				</script>
				<?php
}
else if(isset($_COOKIE["staffid"])) 
{  
				?>
				<script language="javascript" type="text/javascript">
					location.href="staffhome.php";
				</script>
				<?php
}
else if(isset($_COOKIE["clientid"]))
{
	
				?>
				<script language="javascript" type="text/javascript">
					location.href="userhome.php";
				</script>
				<?php
} 
else if(isset($_COOKIE["studentid"]))
{
	
				?>
				<script language="javascript" type="text/javascript">
					location.href="studenthome.php";
				</script>
				<?php
} 

?>
