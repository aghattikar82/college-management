<?php  
try

{
include("connection.php");
	
	$name=$_POST["name"];
	$course=$_POST["course"];
	$year=$_POST["year"];
	$amountpaid=$_POST["amountpaid"];
	
  $i=$con->query("insert into tblpayfees(name,course,year,amountpaid,createdate,paidto,softdelete,softdeletedate) values('$name','$course','$year',$amountpaid,date_format(now(),'%d-%m-%Y'),'accountant','0','-')");

	$con->close();



	if(intval($i)==1)
	{
		header("Location:payfees.php?msg=Fees Paid Successfully");

	}
	else
	{
		//header("Location:payfees.php?msg=Payment Failed");

	}
	
	}

	catch(exception $exc)
	{
                       print("Exception".$exc);
	}
?>

