
<?php   session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>CHANGE PASSWORD</title>
<?php  include("design/head.php")?>
    
<script language="javascript" type="text/javascript">
    history.forward();
</script>

<script type="text/javascript" language="javascript">
function change()
{
    if(form.txtcurrentpassword.value=="")
    {
        form.txtcurrentpassword.focus();
        alert("Enter Current Password");
        return false;
    }
    else if(form.txtnewpassword.value=="")
    {
        form.txtnewpassword.focus();
        alert("Enter New Password");
        return false;
    }
    else if(form.txtconifrmpassword.value=="")
    {
        form.txtconifrmpassword.focus();
        alert("Enter Confirm Password");
        return false;
    }
    else if(form.txtconifrmpassword.value!=form.txtnewpassword.value)
    {
        form.txtconifrmpassword.focus();
        alert("Confirm Password should be same ");
        return false;
    }
}
</script>
<script src="js/jquery-1.4.2.min.js"></script>
<script>
$(function() {
  $("#txtcurrentpassword").focus();
});            
</script>


<?php 
    if(isset($_COOKIE["adarshid"]))
    {
        //$link=("index.php?msg=Session Expired!Please Relogin");
    }
?>

</head>
<?php  include("design/staffmid.php")?>
<h3>Change Password</h3>
<body>

    <div style="height:40px; "><div style="height:40px;"></div></div>

<form action="changepasswordsave.php" name="form" method="post">

<!--<div style="height:40px; "><div style="height:40px;"></div></div>-->

<table class="table">
    <tr>
        
        <td><input required style="border-radius:5px;" class="form-control form-control" placeholder="Enter Current Password" type="password" id="txtcurrentpassword" name="txtcurrentpassword" /></td>
    </tr>
    <tr>
        
        <td><input required style="border-radius:5px;" class="form-control form-control" placeholder="Enter New Password" type="password" name="txtnewpassword" /></td>
    </tr>
    <tr>
    
        <td><input required style="border-radius:5px;" class="form-control form-control" placeholder="Enter Confirm Password" type="password" name="txtconifrmpassword" /></td>
    </tr>
    <tr>
        <th colspan="2" align="center"><center><input class="btn btn-success" style="border-radius:5px; " type="submit" onclick="return change()"value="Change Password" />
        </center></th>
    </tr>
</table>
</form>
<br/><br/><br/>
<br/><br/><br/>
<br/><br/><br/>
    <?php  include("design/last.php") ?>

</body>
</html>
