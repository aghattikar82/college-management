<!DOCTYPE html>
<html>
<head>
    <?php include("design/head.php") ?>
    
    	<title>Display</title>
</head>
<body>
    <?php include("design/mid.php") ?>
 
    <?php include("connection.php") ?>
	<table align="center" border="1">
		<tr>
		
        <td><b>Name</b></td>
        <td><b>Course</b></td>
        <td><b>Year</b></td>
        <td><b>Amount Paid</b></td>
        
        </tr>
        <?php
        
        $data=$con->query("select name,course,year,amountpaid from tblpayfees order by pid");
        while($row=mysqli_fetch_array($data))
        {

        	print("<tr><td>".$row["name"]."</td>");
            print("<td>".$row["course"]."</td>");
            print("<td>".$row["year"]."</td>");
            print("<td>".$row["amountpaid"]."</td>");
        } 
        $con->close();
        ?>
		
	</table>

    
<?php include("design/last.php") ?>
</body>
</html>