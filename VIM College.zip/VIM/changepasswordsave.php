<?php 	session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><?php  include("connection.php") ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Change Password</title>
<script language="javascript" type="text/javascript">
	history.forward();
</script>

</head>

<body>
<?php 
	if(isset($_COOKIE["staffid"]))
	{
		$link=("index.php?msg=Session Expired!Please Relogin");
	}
		try
		{
			echo "---------1";
			if(strcmp($_COOKIE["staffid"],"admin")==0)  
			{
					$link=("changepassword.php?msg=Password cannot be changed for Administrator");
			}
			else
			{
				echo "---------2";
			
				$current=$_POST["txtcurrentpassword"];
				$newpassword=$_POST["txtnewpassword"];
				$username=$_COOKIE["staffid"];
				$i=$con->query("update userstaffregister set password =aes_encrypt('$newpassword',123) where staffid='$username' and password=aes_encrypt('$current',123)");
				echo $i;
			
				if($i==1)
				{
					?>
						<script language="javascript">
							location.href="changepassword.php?msg=Password Changed";
						</script>

					<?php 
	}
				else
				{
					?>
						<script language="javascript">
							location.href="changepassword.php?msg=Password Update Failed";
						</script>

					<?php 

				}
			}
		}
		catch(exception $exe)
		{
					?>
						<script language="javascript">
							location.href="changepassword.php?msg=Server Error";
						</script>

					<?php 

		}
?>
</body>
</html>
