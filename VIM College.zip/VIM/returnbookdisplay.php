<!DOCTYPE html>
<html>
<head>
    <?php include("design/head.php") ?>
    
    	<title>Display</title>
</head>
<body>
  <?php include("design/mid.php") ?>
    <?php include("connection.php") ?>
	<table align="center" border="1" class="table table-borderd">
		<tr>
		
        <td><b>Student Name </b></td>
        <td><b>Father Name </b></td>
        <td><b>Mobile Number</b></td>
        <td><b>Register Number</b></td>
        <td><b>Book ISBN Number</b></td>
        <td><b>Book return Date</b></td>
        
        </tr>
        <?php
        
        $data=$con->query("select admission.sname,admission.fname,admission.s_mobile_no,admission.regno,tblbookissue.bookisbn,tblbookissue.returndate from admission  inner join tblbookissue on admission.regno=tblbookissue.regno where returndate!='-'");


        while($row=mysqli_fetch_array($data))
        {

        	print("<tr><td>".$row["sname"]."</td>");
          print("<td>".$row["fname"]."</td>");
          print("<td>".$row["s_mobile_no"]."</td>");
          print("<td>".$row["regno"]."</td>");
          print("<td>".$row["bookisbn"]."</td>");
          print("<td>".$row["returndate"]."</td></tr>");
           
        

        } 
        $con->close();
        ?>
		
	</table>
    
 <?php include("design/last.php") ?>
</body>
</html>