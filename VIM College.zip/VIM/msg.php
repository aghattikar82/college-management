<center>
	<?php 
	if(isset($_REQUEST["msg"]))
	{
		print($_REQUEST["msg"]); 
	}
	?>
</center>