<!DOCTYPE html>
<html>
<head>
     <?php include("design/head.php") ?>
  <title>Search</title>
</head>
<body>
   <?php include("design/mid.php") ?>
    <?php include("enquiryformdelete.php") ?>
  <?php include("connection.php") ?>
  <?php include("msg.php") ?>
  <form name="frmsearch" method="post" action="enquiryformsearch.php">
    <table align="center" >
      <tr>
        <td>
          <input type="text" size="50%" name="txtsearch" required placeholder="Enter Enquiry ID" autofocus="on" autocomplete="off" maxlength="30">
          <input type="submit" name="btnsearch" value="Display">
          
        </td>
      </tr>
    </table>
    <?php
    if(isset($_POST["txtsearch"]))
    {
        ?><table align="center" border="1">
        <tr>
             <th>Course</th>
            <th>Full Name</th>
            <th>Date Of Birth</th>
            <th>Address</th>
            <th>Student Number</th>
            <th>Parents Number</th>
            <th>Father Name</th>
            <th>Mother Number</th>
            <th>Average Family Income</th>
            <th>Enquiry Date</th>

        </tr>
          <?php 
          $search=$_POST["txtsearch"];
          
          $data=$con->query("select eid,course,fname,dob,address,snumber,pnumber,fname,mname,afincome,edate from tblenquiryform where eid='$search' or fname like '%$search%' order by eid");
          while($row=mysqli_fetch_array($data))
          {
            ?>
            <tr>
           <td><?php  echo ucwords($row["course"]) ?></td>
            <td><?php  echo ($row["fname"]) ?></td>
            <td><?php  echo ($row["dob"]) ?></td>
            <td><?php  echo ($row["address"]) ?></td>
            <td><?php  echo ($row["snumber"]) ?></td>
            <td><?php  echo ($row["pnumber"]) ?></td>
            <td><?php  echo ($row["fname"]) ?></td>
            <td><?php  echo ($row["mname"]) ?></td>
            <td><?php  echo ($row["afincome"]) ?></td>
            <td><?php  echo ($row["edate"]) ?></td>
            <td><?php<a href='enquiryformdelete.php?eid=".$row["eid"]."'>Delete</a>?></td>
           <form name='frmpayment' action='adminmakepayment.php' method='post'>
            </tr>
</form>


            
            <?php

          }
      }
  ?>
          
        </table>

</form>
 <?php include("design/last.php") ?>
</body>
</html>